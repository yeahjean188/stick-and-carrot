//dotenv 설정
const dotenv = require('dotenv');
dotenv.config();

//port 설정
// const port = process.env.PORT || 3002;

//express 설정
const express = require('express');
const app = express();

//CORS 문제 해결
const cors = require('cors');
app.use(cors({
    origin: 'https://carrot-tales.pages.dev',
    credentials: true,
    optionsSuccessStatus: 200, // 응답 상태 200으로 설정
}));
// 또는 미들웨어로 설정
// app.use((req, res, next) => {
//     res.header("Access-Control-Allow-Origin", "https://carrot-tales.pages.dev");
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//     next();
// });


//path 설정
const path = require('path');

//serverless-http 설정
const serverless = require('serverless-http')

//POST 요청 받을 수 있게 만듦
app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: false })) // for parsing application/x-www-form-urlencoded
app.use(express.static(path.join(__dirname, '../frontend')));

const OpenAI = require('openai');
const openai = new OpenAI({
    apiKey: process.env.OPEN_API_KEY,
});

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', 'https://carrot-tales.pages.dev');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Credentials', 'true');
    next();
});

app.options('/fortuneTell', (req, res) => {
    res.header('Access-Control-Allow-Origin', 'https://carrot-tales.pages.dev');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.send();
});


//gpt POST 요청
app.post('/fortuneTell', async function (req, res) {
    res.setHeader('Access-Control-Allow-Origin', 'https://carrot-tales.pages.dev');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');

    // AWS Lambda 함수에 요청을 전달하는 프록시
    // const axios = require('axios');
    // const lambdaUrl = 'https://62x2jqh5bc6s353c7rzm77iq3u0dubtg.lambda-url.ap-northeast-2.on.aws/fortuneTell';

    // try {
    //     const response = await axios.post(lambdaUrl, req.body, {
    //         headers: {
    //             'Content-Type': 'application/json'
    //         }
    //     });
    //     res.json(response.data);
    // } catch (error) {
    //     console.error("Error forwarding request to Lambda:", error);
    //     res.status(500).json({ error: "Failed to forward request to Lambda" });
    // }

    //프론트엔드에서 보낸 메시지 출력
    let { myName, myAge, myGender, myLike, myHateFood, myStoryContent, userMessages, assistantMessages } = req.body

    let messages = [
        { "role": "system", "content": "You can make English fairy tales for children." },
        { "role": "assistant", "content": "You remember the contents of the previous page. You will continue writing the contents on the next page." },
        { "role": "assistant", "content": "You only write one page of 400 characters in english. You can't move over that." },
        { "role": "assistant", "content": `The name of the main character of the coin book is ${myName}, His age is ${myAge}, His gender is ${myGender}. 
        The story is about interested ${myLike}. And You make up the story to eat well ${myHateFood} which is the food he hates. And the amount of writing is ${myStoryContent}.` }
    ]

    while (userMessages.length != 0 || assistantMessages.length != 0) {
        if (userMessages.length != 0) {
            messages.push(
                JSON.parse('{"role": "user", "content": "' + String(userMessages.shift()).replace(/\n/g, "") + '"}')
            )
        }
        if (assistantMessages.length != 0) {
            messages.push(
                JSON.parse('{"role": "assistant", "content": "' + String(assistantMessages.shift()).replace(/\n/g, "") + '"}')
            )
        }
    }

    const completion = await openai.chat.completions.create({
        messages: messages,
        model: "gpt-3.5-turbo"
    });

    let fortune = completion.choices[0].message['content'];

    res.json({ "assistant": fortune });
});

module.exports.handler = serverless(app)